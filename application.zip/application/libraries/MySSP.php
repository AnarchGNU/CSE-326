<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
class MySSP
{
    public function __construct()
    {
        require_once APPPATH.'SSP.php';
    }
}