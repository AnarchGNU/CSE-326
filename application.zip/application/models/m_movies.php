<?php

if (!defined('BASEPATH'))
    exit('No direct script access allowed');

class M_movies extends CI_Model {

    function __construct() {
        // Call the Model constructor
        parent::__construct();
    }

    function listMovies($num) {

        $query = 'SELECT title, poster_path, movie_id FROM movie WHERE release_date >= DATE_ADD(CURRENT_TIMESTAMP(), INTERVAL -2 YEAR) ORDER BY avg_rating_imdb LIMIT ' . $num;

        $result = $this->db->query($query);
        $result = $result->result();
        

        return $result;
    }

}

// END Admin_model Class

/* End of file admin_model.php */
/* Location: ./application/models/admin_model.php */