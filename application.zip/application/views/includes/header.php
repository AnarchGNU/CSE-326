<div class="left">
  <a href="<?php echo site_url('welcome');?>">Home</a>
  <a href="movie.php">Movies</a>
  <a href="<?php echo site_url("searchMovie")?>">Search</a>
</div>

<div class="right">
  <?php if (isset($this->session->userdata['logged_in'])) {?>
  <a href="<?php echo site_url('welcome/userAccount');?>">Account</a>
  <a href="<?php echo site_url('welcome/logOut');?>">Logout</a>
  <?php } else{?>
  <a href="<?php echo site_url('welcome/registerUser');?>">Sign Up</a>
  <a href="<?php echo site_url('welcome/loginUser');?>">Login</a>
  <?php } ?>
</div>
