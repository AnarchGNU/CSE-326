<?php

class Movie {

    public $title;
    public $poster;
    public $id;
    public $genre;
    public $budget;
    public $year;
    public $rating;
    public $country;
    public $date;

}

class Cast {

    public $actor;
    public $character;

}

class Production {

    public $producer;
    public $movie_id;

}

/**
 * Establish a database connection.
 */
function databaseConnect() {

    static $conn;

    if ($conn === NULL) {
        if ($_SERVER['HTTP_HOST'] == "localhost") {

//      $conn = mysqli_connect('localhost', 'root', 'newpassword', 'PyFlicks');
            $conn = mysqli_connect('localhost', 'root', '', 'movie_recommend');
        } else {
            $conn = mysqli_connect('localhost', 'soco5_MovieUser', 'Y)_t8SeRT~If', 'soco5_PyFlicks');
        }
    }

    if (mysqli_connect_errno()) {
        echo 'Database Connection Failed.';
        return null;
    }

    return $conn;
}

/**
 * Retrieve a list of num movies to display
 * on the home page.
 */
function listMovies($num) {

    $conn = databaseConnect();

    $movies = array();

    $query = 'SELECT title, poster_path, movie_id FROM movie WHERE release_date >= DATE_ADD(CURRENT_TIMESTAMP(), INTERVAL -2 YEAR) ORDER BY avg_rating_imdb LIMIT ' . $num;

    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $movie = new Movie();
            $movie->title = $row["title"];
            $movie->poster = $row["poster_path"];
            $movie->id = $row["movie_id"];
            array_push($movies, $movie);
        }
    } else {
        echo "no results";
    }

    return $movies;
}

function getMovieData($id) {

    $conn = databaseConnect();

    $query = 'SELECT * FROM movie WHERE movie_id = ' . $id . ' LIMIT 1';
    $result = $conn->query($query);
    $row = $result->fetch_assoc();

    $query = 'SELECT * FROM movie_genre WHERE movie_id = ' . $id . ' LIMIT 1';
    $result = $conn->query($query);
    $genre = $result->fetch_assoc();
    $genre = $genre["genre_name"];

    $movie = new Movie();
    $movie->title = $row["title"];
    $movie->poster = $row["poster_path"];
    $movie->id = $id;
    $movie->genre = $genre;
    $movie->budget = $row["budget"];
    $movie->year = $row["year"];
    $movie->rating = $row["avg_rating_imdb"];
    $movie->country = $row["country"];
    $movie->date = $row["release_date"];

    return $movie;
}

/**
  retrieves production information about a movie
 */
function getProducerData($movie_id) {
    $conn = databaseConnect();

    $query = 'SELECT * FROM production WHERE movie_id = ' . $movie_id;

    $result = $conn->query($query);
    $row = $result->fetch_assoc();

    $produce = new Production();

    $produce->producer = $row["production"];
    $produce->movie_id = $movie_id;

    return $produce;
}

/**
  Retrieves cast information from a movie
 */
function getActors($id) {
    $conn = databaseConnect();
    $actors = array();



    $query = 'SELECT * FROM casts WHERE movie_id = ' . $id;
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        while ($row = $result->fetch_assoc()) {
            $cast = new Cast();
            $cast->actor = $row["actor_name"];
            $cast->character = $row["character"];

            array_push($actors, $cast);
        }
    }

    return $actors;
}

function register_user() {
    session_start();

// initializing variables
    $username = "";
    $email = "";
    $errors = array();

// connect to the database
    $db = mysqli_connect('localhost', 'root', '', 'registration');

// REGISTER USER
    if (isset($_POST['reg_user'])) {
        // receive all input values from the form
        $username = mysqli_real_escape_string($db, $_POST['username']);
        $email = mysqli_real_escape_string($db, $_POST['email']);
        $password_1 = mysqli_real_escape_string($db, $_POST['password_1']);
        $password_2 = mysqli_real_escape_string($db, $_POST['password_2']);

        // form validation: ensure that the form is correctly filled ...
        // by adding (array_push()) corresponding error unto $errors array
        if (empty($username)) {
            array_push($errors, "Username is required");
        }
        if (empty($email)) {
            array_push($errors, "Email is required");
        }
        if (empty($password_1)) {
            array_push($errors, "Password is required");
        }
        if ($password_1 != $password_2) {
            array_push($errors, "The two passwords do not match");
        }

        // first check the database to make sure 
        // a user does not already exist with the same username and/or email
        $user_check_query = "SELECT * FROM users WHERE username='$username' OR email='$email' LIMIT 1";
        $result = mysqli_query($db, $user_check_query);
        $user = mysqli_fetch_assoc($result);

        if ($user) { // if user exists
            if ($user['username'] === $username) {
                array_push($errors, "Username already exists");
            }

            if ($user['email'] === $email) {
                array_push($errors, "email already exists");
            }
        }

        // Finally, register user if there are no errors in the form
        if (count($errors) == 0) {
            $password = md5($password_1); //encrypt the password before saving in the database

            $query = "INSERT INTO users (username, email, password) 
  			  VALUES('$username', '$email', '$password')";
            mysqli_query($db, $query);
            $_SESSION['username'] = $username;
            $_SESSION['success'] = "You are now logged in";
            header('location: index.php');
        }
    }
}

?>
