<head>
    <?php require_once 'includes/head.php'; ?>

    <!-- Title -->
    <title>PyFlicks - Find New Movies</title>
</head>

<body>
    <header>
        <?php require_once 'includes/header.php'; ?>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    </header>
    <main>
        <div class="row panel panel-success" style="margin-top:2%;">
            <div class="panel-heading lead">
                <div class="row">
                    <div class="col-lg-8 col-md-8"><i class="fa fa-users"></i> View Movie Details</div>                    
                </div>
            </div>
            <div class="panel-body">



                <div class="row">
                    <div class="col-lg-12 col-md-12">

                        <div class="row">
                            <div class="col-lg-3 col-md-3">
                                <center>
                                    <span class="text-left">
                                        <img src="<?php echo base_url('images/' . $movie_metadata[0]->poster_path) ?>" class="img-responsive img-thumbnail">                      
                                    </span>
                                </center>
                            </div>
                            <div class="col-lg-9 col-md-9">
                                <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#Summery" class="text-success"><i class="fa fa-indent"></i> Movie Summary</a></li>
                                    <li><a data-toggle="tab" href="#castdetails" class="text-success"><i class="fa fa-bookmark-o"></i> Cast Details</a></li>
                                    	
                                </ul>

                                <div class="tab-content">
                                    <div id="Summery" class="tab-pane fade in active">

                                        <div class="table-responsive panel">
                                            <table class="table">
                                                <tbody>

                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-user"></i> Movie Title</td>
                                                        <td><?php echo $movie_metadata[0]->title;?></td>
                                                    </tr>
                                                    <?php if ($movie_metadata[0]->budget>0){?>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-list-ol"></i> Budget</td>
                                                        <td><?php echo $movie_metadata[0]->budget;?></td>
                                                    </tr>
                                                    <?php }?>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-book"></i> IMDB ID</td>
                                                        <td><?php echo $movie_metadata[0]->imdb_id;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-group"></i> Released Year</td>
                                                        <td><?php echo $movie_metadata[0]->year;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-group"></i> Released Date</td>
                                                        <td><?php echo $movie_metadata[0]->release_date;?></td>
                                                    </tr>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-calendar">Avg. Rating (IMDB)</i> </td>
                                                        <td><?php echo $movie_metadata[0]->avg_rating_imdb;?></td>
                                                    </tr>

                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-university"></i> Country of Origin</td>
                                                        <td><?php echo $movie_metadata[0]->country;?></td>                                                               
                                                    </tr>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-university"></i> Original Language</td>
                                                        <td><?php echo $movie_metadata[0]->original_language;?></td>                                                               
                                                    </tr>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-university"></i> Original Language</td>
                                                        <td><?php echo $movie_metadata[0]->original_language;?></td>                                                               
                                                    </tr>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-university"></i> Movie Genres</td>
                                                        <td>
                                                            <?php 
                                                                $genre_names = "";
                                                                foreach($movie_genre as $each_genre){
                                                                   $genre_names = $genre_names." ".$each_genre->genre_name.",";
                                                                }
                                                                echo substr($genre_names, 0, -1);
                                                            ?>
                                                        </td>                                                               
                                                    </tr>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-university"></i> Production Companies</td>
                                                        <td>
                                                            <?php
                                                                $production_companies = "";
                                                                foreach($movie_production as $each_production){
                                                                    $production_companies = $production_companies." ".$each_production->production.",";
                                                                }
                                                                echo substr($production_companies, 0, -1);
                                                            ?>
                                                        </td>                                                               
                                                    </tr>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    
                                    <div id="castdetails" class="tab-pane fade">
                                        <div class="table-responsive panel">
                                            <table class="table">
                                                <tbody>
                                                    <?php
                                                        if(count($cast_details)>0){
                                                            foreach($cast_details as $each_details){
                                                    ?>
                                                    
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-home"></i> <?php echo $each_details->character;?></td>
                                                        <td>
                                                            <address>
                                                                <strong>
                                                                    <?php echo $each_details->actor_name;?>
                                                                </strong>    
                                                            </address>
                                                        </td>
                                                    </tr>
                                                            <?php }}else{?>
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-home"></i> </td>
                                                        <td>
                                                            <address>
                                                                We are sorry, no item to show.
                                                            </address>
                                                        </td>
                                                    </tr>
                                                        <?php }?>
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    
                                    

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <!-- /.table-responsive -->

            </div>
        </div>
    </main>
</body>