<!DOCTYPE html>
<html lang="en">

  <head>
    <?php require_once 'includes/head.php'; ?>

    <!-- Title -->
    <title>PyFlicks - Find New Movies</title>
  </head>

  <body>

    <header>
      <?php require_once 'includes/header.php'; ?>
    </header>

    <main>
      <div class="movie-grid">
            <?php if ($this->session->flashdata('flash_message')){?>
            <h5 align="center"><?php echo $this->session->flashdata('flash_message');?></h5>
            <?php }?>
        <?php
          
          foreach($movies as $movie) {
            echo '<a href="'.site_url('movie/findMovie/'.$movie->movie_id). '">';
//            echo '<a href="movie.php?id=' . $movie->movie_id . '">';
            echo '<div class="movie-item">';
            echo '<img class="movie-poster" src="images/' . $movie->poster_path . '">';
            echo '<span class="movie-title">' . $movie->title . '</span>';
            echo '</div>';
            echo '</a>';
          }

        ?>

      </div>
    </main>

    <footer>
      <?php require_once 'includes/footer.php'; ?>
    </footer>

  </body>
</html>
