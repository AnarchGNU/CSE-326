<head>
    <?php require_once 'includes/head.php'; ?>

    <!-- Title -->
    <title>PyFlicks - Find New Movies</title>
</head>
<body>

    <header>
        <?php require_once 'includes/header.php'; ?>
    </header>
    <main>
        <div class="col-lg-4 col-lg-offset-4">
            <h2>Hello There</h2>
            <h5>Please enter the required information below.</h5>    
            <h5 align="center"><?php echo $this->session->flashdata('flash_message');?></h5>
            <?php
            $fattr = array('class' => 'form-signin');
            $form_submit_url = site_url('welcome/loginUserAction');
            echo form_open($form_submit_url, $fattr);
            ?>            
            <div class="form-group">
                <?php echo form_input(array('name' => 'email', 'id' => 'email', 'placeholder' => 'Email', 'class' => 'form-control', 'value' => set_value('email'))); ?>
            <?php echo form_error('email'); ?>
            </div>
            <div class="form-group">
                <?php echo form_input(array('name' => 'password', 'id' => 'password', 'placeholder' => 'password', 'class' => 'form-control', 'value' => set_value('password'))); ?>
            <?php echo form_error('email'); ?>
            </div>
            <?php echo form_submit(array('value' => 'Log in', 'class' => 'btn btn-lg btn-primary btn-block')); ?>
<?php echo form_close(); ?>
        </div>
    </main>
