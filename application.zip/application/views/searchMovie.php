<!DOCTYPE html>
<html lang="en">

    <head>

        <?php require_once 'includes/head.php'; ?>
        <link rel="stylesheet" type="text/css" href="https://code.jquery.com/ui/1.12.1/themes/base/jquery-ui.css">
        <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.10.16/css/dataTables.jqueryui.min.css">
        <link rel="stylesheet" type="text/css" href="<?php echo base_url() ?>/css/responsive.dataTables.min.css">
        <script type="text/javascript" language="javascript" src="<?php echo base_url() ?>/js/jquery.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
        <script type="text/javascript" language="javascript" src="https://cdn.datatables.net/1.10.16/js/dataTables.jqueryui.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url() ?>/js/dataTables.responsive.min.js"></script>
        <!-- Title -->
        <title>PyFlicks - Find New Movies</title>
    </head>

    <body>

        <header>
            <?php require_once 'includes/header.php'; ?>

            <script type="text/javascript">
                var ajax_url = '<?php echo site_url('searchMovie/ajaxSearchMovie'); ?>';
                $(document).ready(function () {

                    // First Data table js code start from here
                    $('#search_movie_grid tfoot th').each(function () {
                        var title = $(this).text();
                        $(this).html('<input type="text" placeholder="Search ' + title + '" />'); // for plainf the columnwise searchbox
                    });
                    oTable = $('#search_movie_grid').DataTable({
                        "processing": true, // for showing the processing text during any activity like, searching,sorting
                        "serverSide": true, // this will take data from server during any activity
                        "bSortable": true, // sorting enable/disable
                        "bSearchable": true, // searching enable or disable
                        "lengthMenu": [[50, 100, 200, -1], [50, 100, 200, "All"]],
                        dom: 'Blfrtip', // this is regex for showing all kind of searching and sorting. there have some other regex you can find more form online.
                        "ajax": {// ajax call from getting the data from database
                            url: ajax_url, // json datasource
                            type: "post", // method  , by default get
                            error: function () {  // error handling
//                            $(".employee-grid-error").html("");
//                            $("#employee-grid").append('<tbody class="employee-grid-error"><tr><th colspan="3">No data found in the server</th></tr></tbody>');
//                            $("#employee-grid_processing").css("display", "none");
                            }
                        },
                        responsive: true,
                        "columns":
                                [
                                    {"data": 0, "searchable": false},
                                    {"data": 1, "searchable": true},
                                    {"data": 2, "searchable": true},
                                    {"data": 3, "searchable": true},
                                    {"data": 4, "searchable": true},
                                    {"render":
                                                function (data, type, row, meta) {
                                                    findURL = '<?php echo site_url("movie/findMovie/")?>'+row[5];
                                                    return '<a href="' + findURL + '" target="_blank">View Details</a>';
                                                }
                                    }

                                ]
                    });
                    // Apply the search
                    oTable.columns().every(function () {
                        var that = this;
                        $('input', this.footer()).on('keyup change', function () {
                            if (that.search() !== this.value) {
                                that.search(this.value)
                                        .draw();
                            }
                        });
                    });
                });
            </script>
        </header>

        <main>
            <div class="movie-grid">
                <table id="search_movie_grid" class="display" style="width:100%">
                    <thead>
                        <tr>
                            <th>Title</th>
                            <th>Year</th>
                            <th>IMDB Rating</th>
                            <th>Country</th>
                            <th>Genre name</th>
                            <th>Movie ID</th>    
                        </tr>
                    </thead>
                    <tfoot>
                        <tr>
                            <th>Title</th>
                            <th>Year</th>
                            <th>IMDB Rating</th>
                            <th>Country</th>
                            <th>Genre name</th>
                            <th>Movie ID</th>
                        </tr>
                    </tfoot>
                </table>

            </div>
        </main>

        <footer>
            <?php require_once 'includes/footer.php'; ?>
        </footer>

    </body>
</html>
