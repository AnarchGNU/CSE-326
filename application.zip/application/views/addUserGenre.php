<head>
    <?php require_once 'includes/head.php'; ?>

    <!-- Title -->
    <title>PyFlicks - Find New Movies</title>
</head>
<body>

    <header>
        <?php require_once 'includes/header.php'; ?>
    </header>
    <main>
        <div class="col-lg-4 col-lg-offset-4">
            <h2>Hello There</h2>
            <h5>Please Select the Genres you like.</h5>    
            <h5 align="center"><?php echo $this->session->flashdata('flash_message');?></h5>
            
            <form action="<?php echo site_url("welcome/addGenreAction")?>" method="post">
                <?php
                    foreach($movie_genre as $each_genre){
                ?>
                <input type="checkbox" name="genre[]" value="<?php echo $each_genre->genre_name;?>" placeholder="<?php echo $each_genre->genre_name;?>" <?php if(in_array($each_genre, $user_genre)){?> checked="checked" <?php }?>><?php echo $each_genre->genre_name;?><br>
                <?php
                    }
                ?>
                <input type="submit" name="Submit" value="Add Genres" />  
            </form>
        </div>
    </main>
