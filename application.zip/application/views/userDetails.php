<head>
    <?php require_once 'includes/head.php'; ?>

    <!-- Title -->
    <title>PyFlicks - Find New Movies</title>
</head>

<body>
    <header>
        <?php require_once 'includes/header.php'; ?>
        <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css" integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
        <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js" integrity="sha384-Tc5IQib027qvyjSMfHjOMaLkfuWVxZxUPnCJA7l2mCWNIpG9mGCD8wGNIcPD7Txa" crossorigin="anonymous"></script>
    </header>
    <main>
        <div class="row panel panel-success" style="margin-top:2%;">
            <div class="panel-heading lead">
                <div class="row">
                    <div class="col-lg-8 col-md-8"><i class="fa fa-users"></i> View User Details</div>  
                    <input type="button" class="btn btn-info" value="Add Movie Genre" onclick="location.href = '<?php echo site_url("welcome/addGenre");?>';">
                    <!--<input type="button" class="btn btn-info" value="Update User Details" onclick="location.href = '<?php echo site_url("welcome/updateUser");?>';">-->
                </div>
            </div>
            <div class="panel-body">



                <div class="row">
                    <div class="col-lg-12 col-md-12">

                        <div class="row">
                            <div class="col-lg-3 col-md-3">
                                <center>
                                    <span class="text-left">
                                        <img src="" alt="No Image" class="img-responsive img-thumbnail">                      
                                    </span>
                                </center>
                            </div>
                            <div class="col-lg-9 col-md-9">
                                <ul class="nav nav-tabs">
                                    <li class="active"><a data-toggle="tab" href="#Summery" class="text-success"><i class="fa fa-indent"></i> User Details</a></li>
                                    
                                  	
                                </ul>

                                <div class="tab-content">
                                    <div id="Summery" class="tab-pane fade in active">

                                        <div class="table-responsive panel">
                                            <table class="table">
                                                <tbody>

                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-user"></i> First Name</td>
                                                        <td><?php echo $user_basic[0]->first_name;?></td>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-list-ol"></i> Last Name</td>
                                                        <td><?php echo $user_basic[0]->last_name;?></td>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-book"></i> Email</td>
                                                        <td><?php echo $user_basic[0]->email;?></td>
                                                    </tr>
                                                    
                                                    <tr>
                                                        <td class="text-success"><i class="fa fa-university"></i> Selected Genres</td>
                                                        <td>
                                                            <?php 
                                                                $genre_names = "";
                                                                foreach($user_genre as $each_genre){
                                                                   $genre_names = $genre_names." ".$each_genre->genre_name.",";
                                                                }
                                                                echo substr($genre_names, 0, -1);
                                                            ?>
                                                        </td>                                                               
                                                    </tr>
                                                    
                                                </tbody>
                                            </table>
                                        </div>
                                    </div>
                                    
                                    
                                    
                                    

                                </div>

                            </div>

                        </div>
                    </div>
                </div>
                <!-- /.table-responsive -->

            </div>
        </div>
    </main>
</body>