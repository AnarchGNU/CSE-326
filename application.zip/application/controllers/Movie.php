<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Movie extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct() {
        parent::__construct();
        $this->load->model("m_common");
    }

    public function index() {
        $this->load->view("searchMovie");
    }

    public function findMovie($movieID) {
        $where['movie_id'] = $movieID;
        $data['movie_metadata'] = $this->m_common->get_row('movie', $where, "*");
        $data['movie_genre'] = $this->m_common->get_row('movie_genre', $where, "genre_name");
        $data['movie_production'] = $this->m_common->get_row('production', $where, "production");
        $data['cast_details'] = $this->m_common->get_row('casts', $where, "actor_name, character");
        
        $this->load->view("findMovie",$data);
    }
}
