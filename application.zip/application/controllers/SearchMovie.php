<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class SearchMovie extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct() {
        parent::__construct();
        $this->load->model("m_common");
    }

    public function index() {
        $this->load->view("searchMovie");
    }

    public function ajaxSearchMovie() {
        $this->output->set_content_type('application/json');
        $link = mysqli_connect($this->db->hostname, $this->db->username, $this->db->password, $this->db->database);
        $columns = array(
            // datatable column index  => database column name
            0 => 'movie_id',
            1 => 'title',
            2 => 'year',
            3 => 'avg_rating_imdb',
            4 => 'country',
            5 => 'genre_names',
            
        );

        $requestData = $_REQUEST;

        // getting total number records without any search
        $sql = "select count(*) as rowcount from 
                (select `movie`.`movie_id` AS `movie_id`,`movie`.`title` AS `title`,`movie`.`year` AS `year`,
                `movie`.`avg_rating_imdb` AS `avg_rating_imdb`,group_concat(`movie_genre`.`genre_name` separator ',') AS `genre_names`,
                `movie`.`country` AS `country` from (`movie` join `movie_genre` on((`movie`.`movie_id` = `movie_genre`.`movie_id`))) group by `movie_genre`.`movie_id`) as temp ";
        $query = $this->db->query($sql);
        $totalData = $query->result();
        $totalFiltered = $totalData[0]->rowcount;  // when there is no search parameter then total number rows = total number filtered rows.



        $sql = "select `movie`.`movie_id` AS `movie_id`,`movie`.`title` AS `title`,`movie`.`year` AS `year`,`movie`.`avg_rating_imdb` AS `avg_rating_imdb`,group_concat(`movie_genre`.`genre_name` separator ',') AS `genre_names`,`movie`.`country` AS `country` from (`movie` join `movie_genre` on((`movie`.`movie_id` = `movie_genre`.`movie_id`))) where 1=1";

        if (!empty($requestData['search']['value'])) {   // if there is a search parameter, $requestData['search']['value'] contains search parameter
            $sql.=" AND ( title LIKE '" . $requestData['search']['value'] . "%' ";
            $sql.=" OR year LIKE '" . $requestData['search']['value'] . "%' ";
            $sql.=" OR genre_name LIKE '" . $requestData['search']['value'] . "%' ";
            $sql.=" OR country LIKE '" . $requestData['search']['value'] . "%' ";
            $sql.=" OR avg_rating_imdb LIKE '" . $requestData['search']['value'] . "%' )";
        }
        foreach ($columns as $key => $each) {
            if (!empty($_POST['columns'][$key]['search']['value'])) {
                $sql.=" and ( " . $each . " LIKE '" . $_POST['columns'][$key]['search']['value'] . "%' )";
            }
        }
        $sql.=' group by `movie_genre`.`movie_id`';
        $sql.=" ORDER BY " . $columns[$requestData['order'][0]['column']] . "   " . $requestData['order'][0]['dir'] . "  LIMIT " . $requestData['start'] . " ," . $requestData['length'] . "   ";
        $query = $this->db->query($sql);
        $query_result = $query->result();
        $totalFiltered = $query->num_rows();

        $data = array();
        foreach($query_result as $obj) {  // preparing an array
            $nestedData = array();

            $nestedData[] = $obj->title;
            $nestedData[] = $obj->year;
            $nestedData[] = $obj->avg_rating_imdb;
            $nestedData[] = $obj->genre_names;
            $nestedData[] = $obj->country;
            $nestedData[] = $obj->movie_id;

            $data[] = $nestedData;
        }



        $json_data = array(
            "draw" => intval($requestData['draw']), // for every request/draw by clientside , they send a number as a parameter, when they recieve a response/data they first check the draw number, so we are sending same number in draw. 
            "recordsTotal" => intval($totalData), // total number of records
            "recordsFiltered" => intval($totalFiltered), // total number of records after searching, if there is no searching then totalFiltered = totalData
            "data" => $data   // total data array
        );

        echo json_encode($json_data);  // send data as json format
    }

}
