<?php

defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

    /**
     * Index Page for this controller.
     *
     * Maps to the following URL
     * 		http://example.com/index.php/welcome
     * 	- or -
     * 		http://example.com/index.php/welcome/index
     * 	- or -
     * Since this controller is set as the default controller in
     * config/routes.php, it's displayed at http://example.com/
     *
     * So any other public methods not prefixed with an underscore will
     * map to /index.php/welcome/<method_name>
     * @see https://codeigniter.com/user_guide/general/urls.html
     */
    function __construct() {
        parent::__construct();
        $this->load->model("m_common");
    }

    public function index() {
        $this->load->model('m_movies');

        $data['movies'] = $this->m_movies->listMovies(12);
        $this->load->view("index", $data);
    }

    public function registerUser() {
        $this->load->view('registerUser');
    }

    public function registerUserAction() {
        $this->form_validation->set_rules('first_name', 'First Name', 'required');
        $this->form_validation->set_rules('last_name', 'Last Name', 'required');
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Email', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('flash_message', 'Please insert all the required information');
            redirect(site_url('welcome/registerUser'));
        } else {
            $where['email'] = $this->input->post('email');
            $select = array("email");
            $isDuplicate = $this->m_common->get_row('user_account', $where, $select);
            if ($isDuplicate) {
                $this->session->set_flashdata('flash_message', 'Please insert all the required information');
                redirect(site_url('welcome/registerUser'));
            } else {

                $clean = $this->security->xss_clean($this->input->post(NULL, TRUE));
                $clean['password'] = sha1($clean['password']);
                $id = $this->m_common->insert_row('user_account', $clean);
                $this->session->set_flashdata('flash_message', 'You account is already created. Please login to enjoy the movies');
                redirect(site_url('welcome/registerUser'));
            };
        }
    }

    public function loginUser() {
        $this->load->view('loginUser');
    }

    public function loginUserAction() {
        $this->form_validation->set_rules('email', 'Email', 'required|valid_email');
        $this->form_validation->set_rules('password', 'Email', 'required');

        if ($this->form_validation->run() == FALSE) {
            $this->session->set_flashdata('flash_message', 'Please insert all the required information');
            redirect(site_url('welcome/loginUser'));
        } else {

            $clean = $this->security->xss_clean($this->input->post(NULL, TRUE));
            $clean['password'] = sha1($clean['password']);
            $where['email'] = $this->input->post('email');
            $where['password'] = $clean['password'];
            $select = array("user_id", "first_name", "last_name");
            $user_info = $this->m_common->get_row('user_account', $where, $select);
            if ($user_info != false) {
                $session_data = array('user_id' => $user_info[0]->user_id, 'first_name' => $user_info[0]->first_name, 'last_name' => $user_info[0]->last_name);
                $this->session->set_userdata('logged_in', $session_data);
                $this->session->set_flashdata('flash_message', 'You have logged in successfully');
                redirect(site_url('welcome'));
            } else {
                $this->session->set_flashdata('flash_message', 'Sorry, the provided information is not correct. Please try again');
                redirect(site_url('welcome/loginUser'));
            }
        }
    }

    public function logOut() {
        // Removing session data
        $session_data = array('user_id' => '', 'first_name' => '', 'last_name' => '');
        $this->session->unset_userdata('logged_in', $session_data);
        $this->session->set_flashdata('flash_message', 'You have successfully logged out');
        redirect(site_url('welcome'));
    }

    public function userAccount() {

        $userData = $this->session->userdata('logged_in');
        $userID = $userData['user_id'];
        $where['user_id'] = $userID;
        $data['user_basic'] = $this->m_common->get_row('user_account', $where, "first_name, last_name, email");
        $data['user_genre'] = $this->m_common->get_row('user_genre', $where, "genre_name");

        $this->load->view("userDetails", $data);
    }

    public function addGenre() {

        $userData = $this->session->userdata('logged_in');
        if (!empty($userData)) {
            $data['movie_genre'] = $this->m_common->get_row('movie_genre', "", "genre_name", "genre_name");
            $data['user_genre'] = $this->m_common->get_row('user_genre', "", "genre_name", "genre_name");

            $this->load->view("addUserGenre", $data);
        }else{
            $this->session->set_flashdata('flash_message', 'Sorry, You need to login first');
            redirect(site_url('welcome/loginUser'));
        }
    }
    
    public function addGenreAction() {

        $userData = $this->session->userdata('logged_in');
        
        if (!empty($userData)) {
            if (!empty($this->input->post('Submit'))){
                $userID = $userData['user_id'];
                $genres = $this->input->post('genre');
                $where['user_id'] = $userID;
                $this->m_common->delete_row('user_genre', $where);
                foreach($genres as $each_genre){
                    $insert_data = array();
                    $insert_data['user_id'] = $userID;
                    $insert_data['genre_name'] = $each_genre;
                    $this->m_common->insert_row('user_genre',$insert_data);
                }
                redirect('welcome/userAccount');
            }
            
        }else{
            $this->session->set_flashdata('flash_message', 'Sorry, You need to login first');
            redirect(site_url('welcome/loginUser'));
        }
    }

}
