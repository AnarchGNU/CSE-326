import RF_Classifier as clf             # Random Forest Classifier encapsulation
import Feature_Vector as fv             # Feature Vector for movie data
from dbConnection import dbConnection   # Database for movie data
import numpy as np                      # Used to pass information between clf and fv
import pandas as pd                     # Used to format database information


### Main method
# Allows main function to be called from another script
def main(give_out=False):

    # Setup movie data base data
    dbobj = dbConnection()
    list_genres = pd.DataFrame(dbobj.fetchAllGenre())

    movies_all = DataFrame(dbobj.selectAllMovie())
    movies_usr = []#DataFrame(dbobj.seletUserMovie(usr)) Something like this?

    vectors_all = []
    vectors_usr = []

    # Build list of all feature vectors
    for movie in movies_all:
        vectors_all.append( fv.mid_to_fv(movie) )

    # Build list of feature vectors for user preferences
    for movie in movies_usr:
        # Find corresponding vector in the list vectors_all
        vectors_usr.append( vectors_all[ movies_all.index(movie) ] )


    # Setup classifer
    RF = clf.RF_Clf()

    # Train classifier
    RF.train(base_vectors, lib_vectors);

    # Get results
    total_out = 10  # Number of results to get
    # If mids_usr==None or out==0, returns ranked list of all movies
    # Output = [ [score,mid] , [score,mid] , ... ]
    recs = RF.score_list(movies_all, vectors_all, mids_usr=movies_usr, out=total_out)
    recs_np = np.array(recs)                    # NumPy array of recommendations
    scores_ranked = (recs_np[:,0]).tolist()     # Ranked list of movie scores
    movies_ranked = (recs_np[:,1]).tolist()     # Ranked list of movie IDs

    # At this point, the user-specific SQL can be updated with the mids and scores
    if give_out:
        return recs
    else:
        # Update SQL directly
        # place update code on this line

### Call main function if this file is executed
if __name__ == "__main__":
    main()
